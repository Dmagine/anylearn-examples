from pathlib import Path
import requests

from anylearn.utils.errors import InvalidArguments, AnyLearnAuthException


WORKSPACE = Path.home() / ".anylearn"
DB_FILE = WORKSPACE / "anylearn.db"
DB_URI = f"sqlite:////{DB_FILE}"

class Configuration(object):
    cluster_address = None
    username = None
    user_id = None
    password = None
    token = None

    def __init__(self,
                 cluster_address=None,
                 username=None,
                 password=None,
                 token=None):
        if cluster_address is None \
         or not any([username and password, token]):
            raise InvalidArguments('无有效登录配置')
        Configuration.cluster_address = cluster_address
        Configuration.username = username
        Configuration.password = password
        Configuration.token = token
        if token is None:
            self.__login()
    
    @classmethod
    def __login(cls):
        res = requests.post('%s/api/user/login' % cls.cluster_address, {
            'username': cls.username,
            'password': cls.password,
        })
        if res.status_code == 200:
            res = res.json()
            cls.token = res['token']
            cls.user_id = res['id']
            cls.username = res['username']
        else:
            raise AnyLearnAuthException()


def init_sdk(cluster_address, username, password):
    Configuration(
        cluster_address=cluster_address,
        username=username,
        password=password
    )
    __init_workspace()


def init_sdk_incontainer(cluster_address):
    Configuration(
        cluster_address=cluster_address,
        token="INCONTAINER"
    )
    __init_workspace()


def __init_workspace():
    if WORKSPACE.is_file():
        WORKSPACE.unlink()
    WORKSPACE.mkdir(exist_ok=True)
    if not DB_FILE.exists():
        DB_FILE.touch()


def print_config():
    print(Configuration.cluster_address)
