'''
所有与AnyLearn User相关的接口
'''
from anylearn.config import Configuration


def create_user():
    pass

def query_user():
    pass

def update_user():
    pass

def delete_user():
    pass
