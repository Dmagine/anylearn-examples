from abc import ABC, abstractclassmethod, abstractmethod

from anylearn.utils.api import (
    url_base,
    post_with_token,
    put_with_token,
    delete_with_token
)
from anylearn.utils.errors import (
    AnyLearnException,
    AnyLearnMissingParamException
)


class BaseObject(ABC):
    
    """具体资源信息配置"""
    _fields = {
        # 资源创建/更新请求包体中必须包含且不能为空的字段
        'required': {
            'create': [],
            'update': [],
        },
        # 资源创建/更新请求包体中包含的所有字段
        'payload': {
            'create': [],
            'update': [],
        },
    }

    def __init__(self, id=None, load_detail=False):
        self.id = id
        if load_detail:
            self.get_detail()

    @abstractclassmethod
    def get_list(self) -> list:
        raise NotImplementedError

    @abstractmethod
    def get_detail(self):
        raise NotImplementedError

    @abstractmethod
    def _namespace(self):
        raise NotImplementedError

    def save(self):
        if self.id:
            self._check_fields(required=self._fields['required']['update'])
            return self._update()
        else:
            self._check_fields(required=self._fields['required']['create'])
            return self._create()

    def _update(self):
        data = self._payload_update()
        res = put_with_token(self._url_update(), data=data)
        if not res or 'data' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        return self.id == res['data']

    def _payload_update(self):
        return {k: self.__getattribute__(k)
                for k in self._fields['payload']['update']}

    def _create(self):
        data = self._payload_create()
        res = post_with_token(self._url_create(), data=data)
        if not res or 'data' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        self.id = res['data']
        return True

    def _payload_create(self):
        return {k: self.__getattribute__(k)
                for k in self._fields['payload']['create']}

    def delete(self):
        self._check_fields(required=['id'])
        res = delete_with_token(self._url_delete(), params={ 'id': self.id })
        if not res or 'data' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        return self.id == res['data']

    def _check_fields(self, required=[]):
        missed = [field
                  for field in required
                  if not self.__getattribute__(field)]
        if missed:
            msg = f"{self.__class__.__name__}缺少必要字段：{missed}"
            raise AnyLearnMissingParamException(msg)

    def _url_create(self):
        return f"{url_base()}/{self._namespace()}/add"

    def _url_update(self):
        return f"{url_base()}/{self._namespace()}/update"

    def _url_delete(self):
        return f"{url_base()}/{self._namespace()}/delete"

    def __repr__(self):
        d = self.__dict__
        kv = ", ".join([f"{k}={d[k]!r}" for k in d])
        return f"{self.__class__.__name__}({kv})"
