from dataclasses import asdict, dataclass, field
import json

from anylearn.config import Configuration
from anylearn.utils.api import url_base, get_with_token, post_with_token
from anylearn.utils.errors import AnyLearnException, AnyLearnMissingParamException
from anylearn.interfaces.base import BaseObject


class EvaluateTaskState:
    """
    训练任务状态标识：
    - 0(CREATED)表示已创建
    - 1(RUNNING)表示运行中
    - 2(SUCCESS)表示已完成
    - -1(DELETED)表示已删除
    - -2(FAIL)表示失败
    - -3(ABORT)表示中断
    """
    CREATED = 0
    RUNNING = 1
    SUCCESS = 2
    DELETED = -1
    FAIL = -2
    ABORT = -3


class EvaluateTaskVisibility:
    """
    项目可见性标识：
    - -1(HIDDEN)表示不可见
    - 1(PRIVATE)表示仅创建者可见
    - 2(PROTECTED)表示所有者可见
    - 3(PUBLIC)表示公开
    """
    HIDDEN = -1
    PRIVATE = 1
    PROTECTED = 2
    PUBLIC = 3


@dataclass
class EvaluateSubTask:
    """
    AnyLearn验证子任务类，以方法映射数据集CRUD相关接口
    """

    id: str = None
    model_id: str = None
    files: list = field(default_factory=list)
    evaluate_params: dict = field(default_factory=dict)
    envs: dict = field(default_factory=dict)
    gpu_num: int = 1
    results: str = None


class EvaluateTask(BaseObject):
    """
    AnyLearn验证项目类，以方法映射数据集CRUD相关接口
    """

    _fields = {
        # 资源创建/更新请求包体中必须包含且不能为空的字段
        'required': {
            'create': ['name', 'sub_tasks'],
            'update': ['id', 'name'],
        },
        # 资源创建/更新请求包体中包含的所有字段
        'payload': {
            'create': ['id', 'name', 'description', 'visibility', 'owner',
                       'params_list'],
            'update': ['id', 'name', 'description', 'visibility', 'owner'],
        },
    }

    def __init__(self, id=None, name=None, description=None, state=None,
                 visibility=None, creator_id=None, owner=None,
                 create_time=None, finish_time=None, params_list=None,
                 sub_tasks=None, secret_key=None, load_detail=False):
        self.id = id
        self.name = name
        self.description = description
        self.state = state
        self.visibility = visibility
        self.creator_id = creator_id
        self.owner = owner
        self.create_time = create_time
        self.finish_time = finish_time
        self.params_list = params_list
        self.sub_tasks = sub_tasks
        self.secret_key = secret_key
        super().__init__(id, load_detail=load_detail)

    @classmethod
    def get_list(cls):
        res = get_with_token(f"{url_base()}/evaluate_task/list")
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        return [
            EvaluateTask(id=e['id'], name=e['name'],
                         description=e['description'], state=e['state'],
                         visibility=e['visibility'],
                         creator_id=e['creator_id'], owner=e['owner'],
                         create_time=e['create_time'],
                         finish_time=e['finish_time'],
                         secret_key=e['secret_key'])
            for e in res
        ]

    def get_detail(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/evaluate_task/query",
                             params={'id': self.id})
        if not res or not isinstance(res, dict):
            raise AnyLearnException("请求未能得到有效响应")
        self.__init__(id=res['id'], name=res['name'],
                      description=res['description'], state=res['state'],
                      visibility=res['visibility'],
                      creator_id=res['creator_id'], owner=res['owner'],
                      create_time=res['create_time'],
                      finish_time=res['finish_time'],
                      params_list=res['params_list'],
                      secret_key=res['secret_key'])
        if 'results' not in res or not res['results']:
            self.__load_sub_tasks_from_params_list()
        else:
            self.__load_sub_tasks_from_results(res['results'])

    def _create(self):
        self.__dump_sub_tasks_to_params_list()
        return super()._create()

    def get_log(self, limit=100, direction="init", offset=0, includes=False):
        self._check_fields(required=['id'])
        params = {
            'id': self.id,
            'limit': limit,
            'direction': direction,
            'index': offset,
            'self': 1 if includes else 0,
        }
        res = get_with_token(f"{url_base()}/evaluate_task/log", params=params)
        if not res or type(res) != dict:
            raise AnyLearnException("请求未能得到有效响应")
        return res

    def _namespace(self):
        return "evaluate_task"
    
    def __dump_sub_tasks_to_params_list(self):
        sub_tasks = [asdict(t) for t in self.sub_tasks]
        for t in sub_tasks:
            if not t['model_id']:
                raise AnyLearnMissingParamException("EvaluateSubTask缺少必要字段：model_id")
            t['files'] = ",".join(t['files'])
            t['envs'] = ",".join([f"{k}={v}" for k, v in t['envs'].items()])
        self.params_list = json.dumps(sub_tasks)
        return self.params_list

    def __load_sub_tasks_from_params_list(self):
        sub_tasks = json.loads(self.params_list)
        self.sub_tasks = [
            EvaluateSubTask(id=t['id'] if 'id' in t else None,
                            model_id=t['model_id'],
                            files=t['files'].split(",") if t['files'] else [],
                            evaluate_params=t['evaluate_params'],
                            envs={kv[0]: kv[1]
                                    for kv in [
                                        env.split("=")
                                        for env in t['envs'].split(",")
                                    ]} if 'envs' in t and t['envs'] else {},
                            gpu_num=t['gpu_num'] if 'gpu_num' in t else 1,
                            results=t['results'] if 'results' in t else None)
            for t in sub_tasks
        ]
        return self.sub_tasks

    def __load_sub_tasks_from_results(self, results: list):
        self.sub_tasks = [
            EvaluateSubTask(id=t['id'],
                            model_id=t['model_id'],
                            files=t['files'].split(","),
                            evaluate_params=json.loads(t['args']),
                            envs={kv[0]: kv[1]
                                    for kv in [
                                        env.split("=")
                                        for env in t['envs'].split(",")
                                    ]} if t['envs'] else {},
                            gpu_num=t['gpu_num'], results=t['results'])
            for t in results
        ]
        return self.sub_tasks
