'''
所有与AnyLearn Project相关的接口
'''
from anylearn.config import Configuration
from anylearn.utils.api import url_base, get_with_token, post_with_token, put_with_token, delete_with_token
from anylearn.utils.errors import AnyLearnException, AnyLearnMissingParamException
from anylearn.utils import no_none_filter
from anylearn.interfaces.base import BaseObject
from anylearn.interfaces.train_task import TrainTask


class ProjectVisibility:
    """
    项目可见性标识：
    - -1(HIDDEN)表示不可见
    - 1(PRIVATE)表示仅创建者可见
    - 2(PROTECTED)表示所有者可见
    - 3(PUBLIC)表示公开
    """
    HIDDEN = -1
    PRIVATE = 1
    PROTECTED = 2
    PUBLIC = 3


class Project(BaseObject):
    """
    AnyLearn项目类，以方法映射项目CRUD相关接口
    """

    _fields = {
        # 资源创建/更新请求包体中必须包含且不能为空的字段
        'required': {
            'create': ['name'],
            'update': ['id', 'name'],
        },
        # 资源创建/更新请求包体中包含的所有字段
        'payload': {
            'create': ['id', 'name', 'description', 'datasets', 'visibility',
                       'owner'],
            'update': ['id', 'name', 'description', 'datasets', 'visibility',
                       'owner'],
        },
    }

    def __init__(self, id=None, name=None, description=None,
                 visibility=3, create_time=None, update_time=None,
                 creator_id=None, datasets: list=None, owner: list=None,
                 load_detail=False):
        self.id = id
        self.name = name
        self.description = description
        self.visibility = visibility
        self.create_time = create_time
        self.update_time = update_time
        self.creator_id = creator_id
        self.datasets = datasets
        self.owner = owner
        super().__init__(id=id, load_detail=load_detail)

    @classmethod
    def get_list(cls):
        res = get_with_token(f"{url_base()}/project/list")
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        return [
            Project(id=item['id'], name=item['name'],
                    description=item['description'],
                    create_time=item['create_time'],
                    update_time=item['update_time'])
            for item in res
        ]

    def get_detail(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/project/query",
                             params={'id': self.id})
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        res = res[0]
        self.__init__(id=res['id'], name=res['name'],
                      description=res['description'],
                      visibility=res['visibility'],
                      create_time=res['create_time'],
                      update_time=res['update_time'],
                      creator_id=res['creator_id'],
                      datasets=res['datasets'],
                      owner=res['owner'])

    def get_train_tasks(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/train_task/list",
                             params={'project_id': self.id})
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        return [
            TrainTask(id=item['id'], name=item['name'],
                      description=item['description'], state=item['state'],
                      secret_key=item['secret_key'],
                      results_id=item['results_id'],
                      create_time=item['create_time'],
                      finish_time=item['finish_time'])
            for item in res
        ]

    def _namespace(self):
        return "project"
