from abc import ABC, abstractmethod
import asyncio
import cgi
import os

import aiofiles
import aiohttp
import requests

from anylearn.config import Configuration
from anylearn.utils.api import url_base
from anylearn.utils.errors import AnyLearnException

class ResourceDownloader(ABC):
    """
    资源下载接口
    """
    @abstractmethod
    def run(self, resource_id: str, save_path: str):
        """
        执行资源下载
        """
        raise NotImplementedError


class AsyncResourceDownloader(ResourceDownloader):
    """
    资源异步下载工具类
    """

    def run(self, resource_id: str, save_path: str):
        return asyncio.run(self.__run(resource_id=resource_id,
                                      save_path=save_path))

    async def __run(self, resource_id: str, save_path: str):
        """执行异步下载请求

        Args:
            resource_id: 后端资源ID
            save_path: 资源下载保存路径

        Returns:
            bool: 下载成功与否

        Raises:
            ClientResponseError: 当下载过程中出错时由aiohttp包（默认情况）抛出错误
        """

        headers = {'Authorization': f"Bearer {Configuration.token}"}
        async with aiohttp.ClientSession(headers=headers) as session:
            task = self.__do_download(session=session,
                                      resource_id=resource_id,
                                      save_path=save_path)
            res = await asyncio.gather(task)
        return res

    async def __do_download(self, session: aiohttp.ClientSession,
                            resource_id: str,
                            save_path: str):

        res = await session.get(url=f"{url_base()}/resource/download",
                                raise_for_status=True,
                                params={
                                    'file_id': resource_id,
                                })

        content_header = res.headers.get('Content-Disposition')
        _, params = cgi.parse_header(content_header)
        fileName = params['filename']
        f = await aiofiles.open(f"{save_path}/{fileName}", mode='wb')
        await f.write(await res.read())
        await f.close()
        return fileName


class SyncResourceDownloader(ResourceDownloader):
    """
    资源同步下载工具类
    """

    def run(self, resource_id: str, save_path: str):
        headers = {'Authorization': f"Bearer {Configuration.token}"}

        res = requests.get(url=f"{url_base()}/resource/download",
                           headers=headers,
                           params={
                               'file_id': resource_id,
                           })
        res.raise_for_status()

        content_header = res.headers.get('Content-Disposition')
        _, params = cgi.parse_header(content_header)
        fileName = params['filename']
        with open(f"{save_path}/{fileName}", 'wb') as f:
            f.write(res.content)
        return fileName
