import os
import cgi

from anylearn.interfaces.base import BaseObject
from anylearn.interfaces.resource.resource_uploader import ResourceUploader
from anylearn.interfaces.resource.resource_downloader import ResourceDownloader
from anylearn.utils.errors import AnyLearnException
from anylearn.utils.api import (
    url_base,
    get_with_token,
    post_with_token,
)


class Resource(BaseObject):

    """具体资源信息配置"""
    _fields = {
        # 资源创建/更新请求包体中必须包含且不能为空的字段
        'required': {
            'create': ['name', 'filename'],
            'update': ['id', 'name'],
        },
        # 资源创建/更新请求包体中包含的所有字段
        'payload': {
            'create': ['name', 'description', 'visibility', 'owner',
                       'filename'],
            'update': ['id', 'name', 'description', 'visibility', 'owner'],
        },
    }

    def __init__(self, id=None, name=None, description=None, state=None,
                 visibility=3, upload_time=None, filename=None,
                 is_zipfile=None, file_path=None, size=None, creator_id=None,
                 node_id=None, owner=None, load_detail=False):
        self.name = name
        self.description = description
        self.state = state
        self.visibility = visibility
        self.upload_time = upload_time
        self.filename = filename
        self.is_zipfile = is_zipfile
        self.file_path = file_path
        self.size = size
        self.creator_id = creator_id
        self.node_id = node_id
        self.owner = owner
        super().__init__(id=id, load_detail=load_detail)

    @classmethod
    def list_dir(cls, resource_id):
        assert resource_id
        return get_with_token(f"{url_base()}/resource/listdir",
                              params={ 'file_id': resource_id })
    
    @classmethod
    def upload_file(cls, resource_id: str, file_path: str,
                    uploader: ResourceUploader,
                    chunk_size: int=2048000):
        """
        对指定路径的本地文件进行分割并使用aiohttp异步上传
        """

        assert resource_id, file_path

        # 读取选定文件的内容并根据chunk_size进行切割
        file_size = os.path.getsize(file_path)
        n_chunks = (file_size // chunk_size) + 1
        with open(file_path, 'rb') as f:
            chunks = [f.read(chunk_size) for i in range(n_chunks)]
        
        # 执行异步上传
        uploader.run(resource_id=resource_id, chunks=chunks)

        # 告知后端上传结束
        res = post_with_token(f"{url_base()}/resource/upload_finish",
                              data={ 'file_id': resource_id })
        return not not res

    @classmethod
    def download_file(cls, resource_id: str, save_path: str,
                      downloader: ResourceDownloader):
        """
        把服务器资源使用aiohttp异步下载到本地指定的文件夹
        """

        assert resource_id, save_path
        if not os.path.exists(save_path):
            raise AnyLearnException(f"保存路径{save_path}不存在")

        # 执行异步下载
        return downloader.run(resource_id=resource_id, save_path=save_path)


class ResourceState:
    """
    资源状态标识：
    - 1(CREATED)表示已创建
    - 2(UPLOADING)表示上传中
    - 3(READY)表示就绪
    - -1(DELETED)表示已删除
    - -2(ERROR)表示出错
    """
    CREATED = 1
    UPLOADING = 2
    READY = 3
    DELETED = -1
    ERROR = -2


class ResourceVisibility:
    """
    资源可见性标识：
    - -1(HIDDEN)表示不可见
    - 1(PRIVATE)表示仅创建者可见
    - 2(PROTECTED)表示所有者可见
    - 3(PUBLIC)表示公开
    """
    HIDDEN = -1
    PRIVATE = 1
    PROTECTED = 2
    PUBLIC = 3
