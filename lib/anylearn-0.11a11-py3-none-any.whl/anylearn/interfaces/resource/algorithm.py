import json

from anylearn.utils.api import url_base, get_with_token
from anylearn.utils.errors import AnyLearnException
from anylearn.interfaces.resource.resource import Resource

class Algorithm(Resource):
    """
    AnyLearn算法类，以方法映射算法CRUD相关接口
    """

    """具体资源信息配置"""
    _fields = {
        # 资源创建/更新请求包体中必须包含且不能为空的字段
        'required': {
            'create': ['name', 'filename', 'mirror_id', 'train_params',
                       'evaluate_params'],
            'update': ['id', 'name'],
        },
        # 资源创建/更新请求包体中包含的所有字段
        'payload': {
            'create': ['name', 'description', 'visibility', 'owner',
                       'filename', 'tags', 'mirror_id', 'train_params',
                       'evaluate_params', 'follows_anylearn_norm',
                       'entrypoint_training', 'output_training',
                       'entrypoint_evaluation', 'output_evaluation'],
            'update': ['id', 'name', 'description', 'visibility', 
                       'owner', 'tags', 'mirror_id', 'train_params',
                       'evaluate_params'],
        },
    }

    __train_params = __evaluate_params = None
    required_train_params = required_evaluate_params = []
    default_train_params = default_evaluate_params = {}

    def __init__(self, id=None, name=None, description=None, state=None,
                 visibility=3, upload_time=None, filename=None,
                 is_zipfile=None, file_path=None, size=None, creator_id=None,
                 node_id=None, owner=None, tags=None, mirror_id=None,
                 train_params=None, evaluate_params=None,
                 follows_anylearn_norm=True, entrypoint_training=None,
                 output_training=None, entrypoint_evaluation=None,
                 output_evaluation=None, load_detail=False):
        self.tags = tags
        self.mirror_id = mirror_id
        self.train_params = train_params
        self.evaluate_params = evaluate_params
        self.follows_anylearn_norm = follows_anylearn_norm
        self.entrypoint_training = entrypoint_training
        self.output_training = output_training
        self.entrypoint_evaluation = entrypoint_evaluation
        self.output_evaluation = output_evaluation
        super().__init__(id=id, name=name, description=description,
                         state=state, visibility=visibility,
                         upload_time=upload_time, filename=filename,
                         is_zipfile=is_zipfile, file_path=file_path, size=size,
                         creator_id=creator_id, node_id=node_id, owner=owner,
                         load_detail=load_detail)

    @classmethod
    def get_list(cls) -> list:
        res = get_with_token(f"{url_base()}/algorithm/list")
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        return [
            Algorithm(id=a['id'], name=a['name'], description=a['description'],
                      state=a['state'], visibility=a['visibility'],
                      upload_time=a['upload_time'], tags=a['tags'],
                      follows_anylearn_norm=a['follows_anylearn_norm'])
            for a in res
        ]

    def get_detail(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/algorithm/query",
                             params={'id': self.id})
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        res = res[0]
        self.__init__(id=res['id'], name=res['name'],
                      description=res['description'], state=res['state'],
                      visibility=res['visibility'],
                      upload_time=res['upload_time'], filename=res['filename'],
                      is_zipfile=True if res['is_zipfile'] == 1 else False,
                      file_path=res['file'], size=res['size'],
                      creator_id=res['creator_id'], node_id=res['node_id'],
                      owner=res['owner'], tags=res['tags'],
                      mirror_id=res['mirror_id'],
                      train_params=res['train_params'],
                      evaluate_params=res['evaluate_params'],
                      follows_anylearn_norm=res['follows_anylearn_norm'],
                      entrypoint_training=res['entrypoint_training'],
                      output_training=res['output_training'],
                      entrypoint_evaluation=res['entrypoint_evaluation'],
                      output_evaluation=res['output_evaluation'])

    def _namespace(self):
        return "algorithm"

    # def _create(self):
    #     if not self.follows_anylearn_norm:
    #         self._check_fields(required=['entrypoint_training',
    #                                      'output_training'])
    #     return super()._create()

    def _payload_create(self):
        payload = super()._payload_create()
        payload['follows_anylearn_norm'] = int(payload['follows_anylearn_norm'])
        return self.__payload_algo_params_to_str(payload)

    def _payload_update(self):
        return self.__payload_algo_params_to_str(super()._payload_update())

    def __payload_algo_params_to_str(self, payload):
        if 'train_params' in payload:
            payload['train_params'] = json.dumps(payload['train_params'])
        if 'evaluate_params' in payload:
            payload['evaluate_params'] = json.dumps(payload['evaluate_params'])
        return payload

    @property
    def train_params(self):
        return self.__train_params

    @train_params.setter
    def train_params(self, train_params):
        if not train_params:
            return
        (self.__train_params, 
         self.required_train_params, 
         self.default_train_params) = self.__parse_json_params(train_params)

    @property
    def evaluate_params(self):
        return self.__evaluate_params

    @evaluate_params.setter
    def evaluate_params(self, eval_params):
        if not eval_params:
            return
        (self.__evaluate_params, 
         self.required_evaluate_params, 
         self.default_evaluate_params) = self.__parse_json_params(eval_params)

    def __parse_json_params(self, json_params):
        params = json.loads(json_params)
        required_params = [p for p in params if 'default' not in p]
        default_params = {p['name']: p['default'] for p in params
                          if 'default' in p}
        return params, required_params, default_params
