from anylearn.utils.api import url_base, get_with_token
from anylearn.utils.errors import AnyLearnException
from anylearn.interfaces.resource.resource import Resource

class Model(Resource):
    """
    AnyLearn模型类，以方法映射模型CRUD相关接口
    """

    """具体资源信息配置"""
    _fields = {
        # 资源创建/更新请求包体中必须包含且不能为空的字段
        'required': {
            'create': ['name', 'filename', 'algorithm_id'],
            'update': ['id', 'name'],
        },
        # 资源创建/更新请求包体中包含的所有字段
        'payload': {
            'create': ['name', 'description', 'visibility', 'owner',
                       'filename', 'algorithm_id'],
            'update': ['id', 'name', 'description', 'visibility', 'owner',
                       'algorithm_id'],
        },
    }

    def __init__(self, id=None, name=None, description=None, state=None,
                 visibility=3, upload_time=None, filename=None,
                 is_zipfile=None, file_path=None, size=None, creator_id=None,
                 node_id=None, owner=None, algorithm_id=None, load_detail=False):
        self.algorithm_id = algorithm_id
        super().__init__(id=id, name=name, description=description,
                         state=state, visibility=visibility,
                         upload_time=upload_time, filename=filename,
                         is_zipfile=is_zipfile, file_path=file_path, size=size,
                         creator_id=creator_id, node_id=node_id, owner=owner,
                         load_detail=load_detail)

    @classmethod
    def get_list(cls) -> list:
        res = get_with_token(f"{url_base()}/model/list")
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        return [
            Model(id=m['id'], name=m['name'], description=m['description'],
                  state=m['state'], visibility=m['visibility'],
                  upload_time=m['upload_time'], creator_id=m['creator_id'],
                  node_id=m['node_id'], owner=m['owner'],
                  algorithm_id=m['algorithm_id'])
            for m in res
        ]

    def get_detail(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/model/query",
                             params={'id': self.id})
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        res = res[0]
        self.__init__(id=res['id'], name=res['name'],
                      description=res['description'], state=res['state'],
                      visibility=res['visibility'],
                      upload_time=res['upload_time'], filename=res['filename'],
                      is_zipfile=True if res['is_zipfile'] == 1 else False,
                      file_path=res['file'], size=res['size'],
                      creator_id=res['creator_id'], node_id=res['node_id'],
                      owner=res['owner'], algorithm_id=res['algorithm_id'])

    def _namespace(self):
        return "model"
