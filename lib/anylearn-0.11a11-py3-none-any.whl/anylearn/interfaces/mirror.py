from anylearn.utils.api import url_base, get_with_token
from anylearn.utils.errors import AnyLearnException

class Mirror:
    """
    AnyLearn镜像类，仅提供镜像列表接口
    """

    def __init__(self, id=None, name=None, requirements=None):
        self.id = id
        self.name = name
        self.requirements = requirements

    @classmethod
    def get_list(cls) -> list:
        res = get_with_token(f"{url_base()}/mirror/list")
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        return [
            Mirror(id=m['id'], name=m['name'], requirements=m['requirements'])
            for m in res
        ]

    def __str__(self):
        return f"Mirror(name={self.name})"

    def __repr__(self):
        d = self.__dict__
        kv = ", ".join([f"{k}={d[k]!r}" for k in d])
        return f"{self.__class__.__name__}({kv})"
