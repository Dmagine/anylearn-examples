import json

from anylearn.config import Configuration
from anylearn.utils.api import url_base, get_with_token, post_with_token, post_with_secret_key
from anylearn.utils.errors import AnyLearnException, AnyLearnMissingParamException
from anylearn.interfaces.base import BaseObject
from anylearn.interfaces.resource import Resource, ResourceDownloader, AsyncResourceDownloader


class TrainTaskState:
    """
    训练任务状态标识：
    - 0(CREATED)表示已创建
    - 1(RUNNING)表示运行中
    - 2(SUCCESS)表示已完成
    - -1(DELETED)表示已删除
    - -2(FAIL)表示失败
    - -3(ABORT)表示中断
    """
    CREATED = 0
    RUNNING = 1
    SUCCESS = 2
    DELETED = -1
    FAIL = -2
    ABORT = -3


class TrainTask(BaseObject):
    """
    AnyLearn训练任务类，以方法映射训练任务CRUD相关接口
    """

    _fields = {
        # 资源创建/更新请求包体中必须包含且不能为空的字段
        'required': {
            'create': ['name', 'project_id', 'algorithm_id', 'train_params'],
            'update': [],
        },
        # 资源创建/更新请求包体中包含的所有字段
        'payload': {
            'create': ['name', 'description', 'project_id', 'algorithm_id',
                       'train_params', 'envs', 'files', 'visibility'],
            'update': [],
        },
    }

    def __init__(self, id=None, name=None, description=None, state=None,
                 visibility=None, creator_id=None, owner=None, project_id=None,
                 algorithm_id=None, train_params=None, files=None,
                 results_id=None, secret_key=None, create_time=None,
                 finish_time=None, envs=None, gpu_num=0, hpo=False,
                 hpo_search_space=None, final_metric=None, load_detail=False):
        self.name = name
        self.description = description
        self.state = state
        self.visibility = visibility
        self.creator_id = creator_id
        self.owner = owner
        self.project_id = project_id
        self.algorithm_id = algorithm_id
        self.train_params = train_params
        self.files = files
        self.results_id = results_id
        self.secret_key = secret_key
        self.create_time = create_time
        self.finish_time = finish_time
        self.envs = envs
        self.gpu_num = gpu_num
        self.hpo = hpo
        self.hpo_search_space = hpo_search_space
        self.final_metric = final_metric
        super().__init__(id=id, load_detail=load_detail)

    @classmethod
    def get_list(self):
        raise AnyLearnException("Listing is not supported for TrainTask")

    def get_detail(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/train_task/query",
                             params={'id': self.id})
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        res = res[0]
        self.__init__(id=res['id'], name=res['name'],
                      description=res['description'], state=res['state'],
                      visibility=res['visibility'],
                      creator_id=res['creator_id'], owner=res['owner'],
                      algorithm_id=res['algorithm_id'],
                      train_params=res['args'], files=res['files'],
                      results_id=res['results_id'],
                      secret_key=res['secret_key'],
                      create_time=res['create_time'],
                      finish_time=res['finish_time'],
                      envs=res['envs'], gpu_num=res['gpu_num'])

    def _create(self):
        data = self._payload_create()
        if self.hpo:
            if not self.hpo_search_space:
                msg = f"{self.__class__.__name__}缺少必要字段：hpo_search_space" + \
                        "——当开启超参数自动调优时（hpo==True），hpo_search_space为必填字段"
                raise AnyLearnMissingParamException(msg)
            data['hpo'] = 1
            data['hpo_search_space'] = json.dumps(self.hpo_search_space)
        res = post_with_token(self._url_create(), data=data)
        if not res or 'data' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        self.id = res['data']
        return True
    
    def _update(self):
        # No update for train task
        pass

    def get_log(self, limit=100, direction="init", offset=0, includes=False):
        self._check_fields(required=['id'])
        params = {
            'id': self.id,
            'limit': limit,
            'direction': direction,
            'index': offset,
            'self': 1 if includes else 0,
        }
        res = get_with_token(f"{url_base()}/train_task/log", params=params)
        if not res or type(res) != list:
            raise AnyLearnException("请求未能得到有效响应")
        return res

    def get_status(self):
        self._check_fields(required=['id', 'secret_key'])
        params = {
            'id': self.id,
            'secret_key': self.secret_key,
        }
        res = get_with_token(f"{url_base()}/train_task/status", params=params)
        if not res or type(res) != dict:
            raise AnyLearnException("请求未能得到有效响应")
        return res

    def download_results(self, save_path: str, downloader=None):
        if self.state != TrainTaskState.SUCCESS:
            raise AnyLearnException("训练未完成或者已删除")
        if not downloader:
            downloader = AsyncResourceDownloader()
        return Resource.download_file(self.results_id, save_path, downloader)

    def report_final_metric(self, metric: float):
        self._check_fields(required=['id', 'secret_key'])
        data = {
            'id': self.id,
            'metric': metric,
        }
        res = post_with_secret_key(f"{url_base()}/train_task/final_metric",
                                   data=data,
                                   secret_key=self.secret_key)
        if not res or type(res) != dict:
            raise AnyLearnException("请求未能得到有效响应")
        self.final_metric = metric
        return res

    def get_final_metric(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/train_task/final_metric",
                             params={'id': self.id})
        if not res or 'final_metric' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        self.final_metric = res['final_metric']
        return res

    def report_intermediate_metric(self, metric: float):
        self._check_fields(required=['id', 'secret_key'])
        data = {
            'id': self.id,
            'metric': metric,
        }
        res = post_with_secret_key(f"{url_base()}/train_task/intermediate_metric",
                                   data=data,
                                   secret_key=self.secret_key)
        if not res or type(res) != dict:
            raise AnyLearnException("请求未能得到有效响应")
        return res

    def get_intermediate_metric(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/train_task/intermediate_metric",
                             params={'id': self.id})
        if not res or type(res) != dict:
            raise AnyLearnException("请求未能得到有效响应")
        return res

    def _namespace(self):
        return "train_task"
