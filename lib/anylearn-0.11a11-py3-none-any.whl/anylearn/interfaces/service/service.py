import json
from os import path
import requests

from anylearn.config import Configuration
from anylearn.utils.api import url_base, get_with_token
from anylearn.utils.errors import AnyLearnException
from anylearn.interfaces.base import BaseObject
from .record import ServiceRecord, ServiceRecordState


class ServiceVisibility:
    """
    服务可见性标识：
    - 1(PRIVATE)表示仅创建者可见
    - 2(PROTECTED)表示所有者可见
    - 3(PUBLIC)表示公开
    """
    PRIVATE = 1
    PROTECTED = 2
    PUBLIC = 3


class ServiceState:
    """
    服务状态标识：
    - 0(CREATED)表示已创建
    - 1(RUNNING)表示已部署运行中
    - -1(DELETED)表示已删除
    - -2(STOPPED)表示已停止
    """
    CREATED = 0
    RUNNING = 1
    DELETED = -1
    STOPPED = -2


class Service(BaseObject):

    _fields = {
        # 资源创建/更新请求包体中必须包含且不能为空的字段
        'required': {
            'create': ['name', 'model_id'],
            'update': ['id', 'name'],
        },
        # 资源创建/更新请求包体中包含的所有字段
        'payload': {
            'create': ['name', 'description', 'visibility', 'model_id', 'envs',
                       'replicas', 'gpu_num', 'owner'],
            'update': ['id', 'name', 'description', 'visibility', 'owner'],
        },
    }

    def __init__(self, id=None, name=None, description=None,
                 visibility=ServiceVisibility.PUBLIC, model_id=None,
                 address=None, secret_key=None, creator_id=None, envs=None,
                 replicas=1, gpu_num=1, state=None, create_time=None,
                 owner=None, load_detail=False):
        self.name = name
        self.description = description
        self.state = state
        self.visibility = visibility
        self.creator_id = creator_id
        self.owner = owner
        self.model_id = model_id
        self.address = address
        self.secret_key = secret_key
        self.envs = envs
        self.replicas = replicas
        self.gpu_num = gpu_num
        self.create_time = create_time
        super().__init__(id=id, load_detail=load_detail)

    @classmethod
    def get_list(self) -> list:
        res = get_with_token(f"{url_base()}/service/list")
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        return [
            Service(id=s['id'], name=s['name'], description=s['description'],
                    state=s['state'], visibility=s['visibility'],
                    owner=s['owner'], model_id=s['model_id'],
                    creator_id=s['creator_id'], address=s['address'],
                    secret_key=s['secret_key'], create_time=s['create_time'])
            for s in res
        ]

    def get_detail(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/service/query",
                             params={'id': self.id})
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        res = res[0]
        self.__init__(id=res['id'], name=res['name'],
                      description=res['description'],
                      visibility=res['visibility'], model_id=res['model_id'],
                      address=res['address'], secret_key=res['secret_key'],
                      creator_id=res['creator_id'], envs=res['envs'],
                      replicas=res['replicas'], gpu_num=res['gpu_num'],
                      state=res['state'], create_time=res['create_time'],
                      owner=res['owner'])

    def scale(self, replicas: int):
        if replicas < 1:
            raise AnyLearnException("服务副本数量不应小于1")
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/service/scale",
                             params={
                                 'id': self.id,
                                 'replicas': replicas,
                             })
        if not res or 'data' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        self.replicas = replicas
        return res.get('data', None) == self.id

    def stop(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/service/stop",
                             params={
                                 'id': self.id,
                             })
        if not res or 'data' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        self.state = ServiceState.STOPPED
        return res.get('data', None) == self.id

    def restart(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/service/restart",
                             params={
                                 'id': self.id,
                             })
        if not res or 'data' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        self.state = ServiceState.RUNNING
        return res.get('data', None) == self.id

    def get_deployment_status(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/service/status",
                             params={
                                 'id': self.id,
                             })
        if not res or 'pods' not in res or 'workers' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        res = {
            'pod_names': [p['name'] for p in res['pods']],
            'workers': res['workers'],
        }
        return res

    def get_log(self, pod_name, limit=100, direction="init", offset=0, includes=False):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/service/log",
                             params={
                                 'id': self.id,
                                 'pod_name': pod_name,
                                 'limit': limit,
                                 'direction': direction,
                                 'index': offset,
                                 'self': 1 if includes else 0,
                             })
        if not res:
            raise AnyLearnException("请求未能得到有效响应")
        return res

    def get_records(self, page=1, size=20, load_detail=False):
        self._check_fields(required=['id'])
        ress = get_with_token(f"{url_base()}/service/record",
                              params={
                                  'id': self.id,
                                  'page_index': page,
                                  'page_size': size,
                              })
        if not ress or not isinstance(ress, list):
            raise AnyLearnException("请求未能得到有效响应")
        return [
            ServiceRecord(id=res['id'], service_id=res['service_id'],
                          inference_data_file_id=res['file_id'],
                          error=res['error'], state=res['state'],
                          create_time=res['create_time'],
                          finish_time=res['finish_time'],
                          load_detail=load_detail)
            for res in ress
        ]

    def predict_online(self, file_binary: str):
        # Ensure service's address
        if not self.address:
            self.get_detail()
        
        # Call service's predict_online API
        url = lambda :Configuration.cluster_address + \
                self.address + \
                "/predict_online"
        res = requests.post(url(), files={'file': file_binary})
        res.raise_for_status()
        res.encoding = "utf-8"
        res = res.json()

        if not res or 'data' not in res:
            raise AnyLearnException("请求未能得到有效响应")
        
        # Fetch prediction results
        record = ServiceRecord(id=res['data'])
        while record.state not in [ServiceRecordState.FINISHED,
                                   ServiceRecordState.FAILED]:
            record.get_detail()
        filename = record.inference_data_file_id
        results = json.loads(json.loads(record.result)[filename])['object']
        return results, record

    def _namespace(self):
        return "service"
