from anylearn.interfaces.base import BaseObject
from anylearn.utils.api import url_base, get_with_token
from anylearn.utils.errors import (
    AnyLearnException,
    AnyLearnNotSupportedException
)


class ServiceRecordState:
    """
    服务状态标识：
    - 0(WAITING)表示等待执行
    - 1(RUNNING)表示执行中
    - 2(FINISHED)表示已完成
    - -1(FAILED)表示失败
    """
    WAITING = 0
    RUNNING = 1
    FINISHED = 2
    FAILED = -1


class ServiceRecord(BaseObject):

    def __init__(self, id, service_id=None, inference_data_file_id=None,
                 state=None, create_time=None, finish_time=None, result=None,
                 error=None, load_detail=False):
        self.service_id = service_id
        self.inference_data_file_id = inference_data_file_id
        self.state = state
        self.create_time = create_time
        self.finish_time = finish_time
        self.result = result
        self.error = error
        super().__init__(id=id, load_detail=load_detail)
    
    @classmethod
    def get_list(self):
        raise AnyLearnNotSupportedException

    def get_detail(self):
        self._check_fields(required=['id'])
        res = get_with_token(f"{url_base()}/service_record/query",
                             params={ 'id': self.id })
        if not res or not isinstance(res, list):
            raise AnyLearnException("请求未能得到有效响应")
        res = res[0]
        self.__init__(id=res['id'], service_id=res['service_id'],
                      inference_data_file_id=res['file_id'],
                      state=res['state'],
                      create_time=res['create_time'],
                      finish_time=res['finish_time'],
                      result=res['result'],
                      error=res['error'])
    
    def save(self):
        raise AnyLearnNotSupportedException

    def delete(self):
        raise AnyLearnNotSupportedException

    def _namespace(self):
        return "service_record"
