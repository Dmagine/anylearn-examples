import requests
from anylearn.config import Configuration

url_base = lambda :Configuration.cluster_address + '/api'

__sess = requests.session()


def __intercept(**kwargs):
    if 'headers' not in kwargs:
        kwargs['headers'] = {}
    kwargs['headers']['Authorization'] = "Bearer %s" % Configuration.token
    return kwargs


def get_with_token(*args, **kwargs):
    kwargs = __intercept(**kwargs)
    res = __sess.get(*args, **kwargs)
    res.raise_for_status()
    res.encoding = "utf-8"
    return res.json()


def post_with_token(*args, **kwargs):
    kwargs = __intercept(**kwargs)
    res = __sess.post(*args, **kwargs)
    res.raise_for_status()
    res.encoding = "utf-8"
    return res.json()


def post_with_secret_key(*args, secret_key, **kwargs):
    if 'headers' not in kwargs:
        kwargs['headers'] = {}
    kwargs['headers']['secret_key'] = secret_key
    res = __sess.post(*args, **kwargs)
    res.raise_for_status()
    res.encoding = "utf-8"
    return res.json()


def delete_with_token(*args, **kwargs):
    kwargs = __intercept(**kwargs)
    res = __sess.delete(*args, **kwargs)
    res.raise_for_status()
    res.encoding = "utf-8"
    return res.json()


def put_with_token(*args, **kwargs):
    kwargs = __intercept(**kwargs)
    res = __sess.put(*args, **kwargs)
    res.raise_for_status()
    res.encoding = "utf-8"
    return res.json()
