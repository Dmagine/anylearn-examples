import json
import logging
from pathlib import Path
import random
import shutil
import string
from threading import Thread
import time
from typing import Union

from ..utils.errors import AnyLearnException, AnyLearnNotSupportedException
from ..interfaces import (
    EvaluateSubTask,
    EvaluateTask,
    EvaluateTaskVisibility,
    Mirror,
    Project,
    ProjectVisibility,
    TrainTask,
)
from ..interfaces.resource import (
    Algorithm,
    AsyncResourceUploader,
    Dataset,
    Model,
    Resource,
    ResourceState,
    ResourceUploader,
    ResourceVisibility,
)


_logger = logging.getLogger('anylearn_sdk_quickstart')
_logger.setLevel(logging.INFO)

DEFAULT_TRAIN_PARAMS = "[{\"name\":\"dataset\",\"type\":\"dataset\",\"suggest\":1}]"
DEFAULT_EVAL_PARAMS = "[{\"name\":\"dataset\",\"type\":\"dataset\",\"suggest\":1},\
                        {\"name\":\"model_path\",\"alias\":\"\",\"description\":\"\",\"type\":\"model\",\"suggest\":1}]"


def generate_random_name() -> str:
    return ''.join(random.sample(string.ascii_lowercase + string.digits, 8))


def create_project_workspace(project_workspace_name: str,
                             anylearn_workspace_name: str=".anylearn") -> Path:
    path = Path.home() / anylearn_workspace_name / project_workspace_name
    path.mkdir(parents=True, exist_ok=True)
    return path


def quick_train(algorithm_dir: str, dataset_dir: str,
                entrypoint: str, output: str,
                resource_uploader: ResourceUploader=None,
                resource_polling: Union[float, int]=5,
                dataset_hyperparam_name: str="dataset",
                hyperparams: dict={}) -> TrainTask:
    __check_algo_minimum_requirements(algorithm_dir)

    mirror = __get_quickstart_mirror()
    
    # Generate random names
    algo_name = generate_random_name()
    dset_name = generate_random_name()
    project_name = generate_random_name()
    train_task_name = generate_random_name()

    # Prepare algo/dset archives
    workspace = create_project_workspace(project_workspace_name=project_name)
    algo_zip = shutil.make_archive(workspace / algo_name, "zip", algorithm_dir)
    dset_zip = shutil.make_archive(workspace / dset_name, "zip", dataset_dir)

    algo = __create_algo(mirror, algo_name,
                         entrypoint_training=entrypoint,
                         output_training=output)
    dset = __create_dset(dset_name)
    project = __create_project(project_name, dset)

    __upload_algo(algo, algo_zip,
                  uploader=resource_uploader,
                  polling=resource_polling)
    __upload_dset(dset, dset_zip,
                  uploader=resource_uploader,
                  polling=resource_polling)

    return __create_train_task(train_task_name, algo, dset, project,
                               dataset_hyperparam_name,
                               hyperparams)


def quick_evaluate(model_dir: str, algorithm_dir: str, dataset_dir: str,
                   entrypoint: str, output: str,
                   resource_uploader: ResourceUploader=None,
                   resource_polling: Union[float, int]=5,
                   model_hyperparam_name: str="model_path",
                   dataset_hyperparam_name: str="dataset",
                   hyperparams: dict={}) -> EvaluateTask:
    __check_algo_minimum_requirements(algorithm_dir)

    mirror = __get_quickstart_mirror()
    
    # Generate random names
    algo_name = generate_random_name()
    dset_name = generate_random_name()
    modl_name = generate_random_name()
    eval_name = generate_random_name()

    # Prepare algo/dset/model archives
    workspace = create_project_workspace(project_workspace_name=eval_name)
    algo_zip = shutil.make_archive(workspace / algo_name, "zip", algorithm_dir)
    dset_zip = shutil.make_archive(workspace / dset_name, "zip", dataset_dir)
    modl_zip = shutil.make_archive(workspace / modl_name, "zip", model_dir)

    algo = __create_algo(mirror, algo_name,
                         entrypoint_evaluation=entrypoint,
                         output_evaluation=output)
    dset = __create_dset(dset_name)
    modl = __create_modl(modl_name, algo)

    __upload_algo(algo, algo_zip,
                  uploader=resource_uploader,
                  polling=resource_polling)
    __upload_dset(dset, dset_zip,
                  uploader=resource_uploader,
                  polling=resource_polling)
    __upload_modl(modl, modl_zip,
                  uploader=resource_uploader,
                  polling=resource_polling)

    return __create_eval_task(eval_name, modl, algo, dset,
                              model_hyperparam_name,
                              dataset_hyperparam_name,
                              hyperparams)


def __check_algo_minimum_requirements(algorithm_dir):
    algo_path = Path(algorithm_dir)
    if not (algo_path / "requirements.txt").exists():
        raise AnyLearnException(("Missing 'requirements.txt' "
                                 "in algorithm folder"))
    if not (algo_path / "anylearn_tools.py").exists():
        (algo_path / "anylearn_tools.py").touch()


def __get_quickstart_mirror():
    mirrors = Mirror.get_list()
    try:
        return next(m for m in mirrors if m.name == "QUICKSTART")
    except:
        raise AnyLearnNotSupportedException((
            "Container for quickstarting is not supported by "
            "the connected backend."
        ))


def __create_algo(mirror, name,
                  entrypoint_training="python train.py",
                  output_training="output",
                  entrypoint_evaluation="python eval.py",
                  output_evaluation="output"):
    algo = Algorithm(name=name, description="SDK_QUICK_TRAINING",
                     visibility=ResourceVisibility.PRIVATE,
                     filename=f"{name}.zip",
                     is_zipfile=True,
                     mirror_id=mirror.id,
                     train_params=DEFAULT_TRAIN_PARAMS,
                     evaluate_params=DEFAULT_EVAL_PARAMS,
                     follows_anylearn_norm=False,
                     entrypoint_training=entrypoint_training,
                     output_training=output_training,
                     entrypoint_evaluation=entrypoint_evaluation,
                     output_evaluation=output_evaluation)
    algo.save()
    return algo


def __create_dset(name):
    dset = Dataset(name=name, description="SDK_QUICK_TRAINING",
                   visibility=ResourceVisibility.PRIVATE,
                   filename=f"{name}.zip",
                   is_zipfile=True)
    dset.save()
    return dset


def __create_modl(name, algo):
    modl = Model(name=name, description="SDK_QUICK_EVALUATION",
                 visibility=ResourceVisibility.PRIVATE,
                 filename=f"{name}.zip",
                 is_zipfile=True,
                 algorithm_id=algo.id)
    modl.save()
    return modl


def __create_project(name, dset):
    project = Project(name=name, description="SDK_QUICK_TRAINING",
                      visibility=ProjectVisibility.PRIVATE,
                      datasets=[dset.id])
    project.save()
    return project


def __create_train_task(name, algo, dset, project, dataset_hyperparam_name,
                        hyperparams):
    train_params = dict({dataset_hyperparam_name: f"${dset.id}"}, **hyperparams)
    train_task = TrainTask(name=name, project_id=project.id,
                           algorithm_id=algo.id,
                           files=[dset.id],
                           train_params=json.dumps(train_params))
    train_task.save()
    train_task.get_detail()
    return train_task


def __create_eval_task(name, modl, algo, dset, model_hyperparam_name, dataset_hyperparam_name, hyperparams):
    eval_params = dict({
                           model_hyperparam_name: f"${modl.id}",
                           dataset_hyperparam_name: f"${dset.id}",
                       },
                       **hyperparams)
    eval_task = EvaluateTask(name=name,
                             sub_tasks=[
                                 EvaluateSubTask(model_id=modl.id,
                                                 files=[dset.id],
                                                 evaluate_params=eval_params)
                             ])
    eval_task.save()
    eval_task.get_detail()
    return eval_task


def __upload_algo(algo, algo_zip, uploader=None, polling=5):
    if not uploader:
        uploader = AsyncResourceUploader()
    t_algo = Thread(target=Resource.upload_file,
                    kwargs={
                        'resource_id': algo.id,
                        'file_path': algo_zip,
                        'uploader': uploader,
                    })
    _logger.info(f"Uploading algorithm {algo.name}...")
    t_algo.start()
    t_algo.join()
    finished = [ResourceState.ERROR, ResourceState.READY]
    while algo.state not in finished:
        time.sleep(polling)
        algo.get_detail()
    if algo.state == ResourceState.ERROR:
        raise AnyLearnException("Error occured when uploading algorithm")
    _logger.info("Successfully uploaded algorithm")


def __upload_dset(dset, dset_zip, uploader=None, polling=5):
    if not uploader:
        uploader = AsyncResourceUploader()
    t_dset = Thread(target=Resource.upload_file,
                    kwargs={
                        'resource_id': dset.id,
                        'file_path': dset_zip,
                        'uploader': uploader,
                    })
    _logger.info(f"Uploading dataset {dset.name}...")
    t_dset.start()
    t_dset.join()
    finished = [ResourceState.ERROR, ResourceState.READY]
    while dset.state not in finished:
        time.sleep(polling)
        dset.get_detail()
    if dset.state == ResourceState.ERROR:
        raise AnyLearnException("Error occured when uploading dataset")
    _logger.info("Successfully uploaded dataset")


def __upload_modl(modl, modl_zip, uploader=None, polling=5):
    if not uploader:
        uploader = AsyncResourceUploader()
    t_modl = Thread(target=Resource.upload_file,
                    kwargs={
                        'resource_id': modl.id,
                        'file_path': modl_zip,
                        'uploader': uploader,
                    })
    _logger.info(f"Uploading dataset {modl.name}...")
    t_modl.start()
    t_modl.join()
    finished = [ResourceState.ERROR, ResourceState.READY]
    while modl.state not in finished:
        time.sleep(polling)
        modl.get_detail()
    if modl.state == ResourceState.ERROR:
        raise AnyLearnException("Error occured when uploading model")
    _logger.info("Successfully uploaded model")
